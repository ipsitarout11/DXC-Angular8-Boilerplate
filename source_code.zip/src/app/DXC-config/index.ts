import { DXCbpConfig } from "@DXC/types";

/**
 * Default DXC Configuration
 *
 *
 */

export const DXCConfig: DXCbpConfig = {
    // Color themes can be defined in src/app/app.theme.scss
    colorTheme: "theme-default",
    customScrollbars: true,
    layout: {
        style: "vertical-app-layout",
        width: "fullwidth",
        navbar: {
            primaryBackground: "DXC-navy-700",
            secondaryBackground: "DXC-navy-900",
            folded: false,
            hidden: false,
            position: "left",
            variant: "vertical-style"
        },
        toolbar: {
            customBackgroundColor: false,
            background: "",
            hidden: false,
            position: "below-static"
        },
        footer: {
            customBackgroundColor: true,
            background: "DXC-navy-900",
            hidden: false,
            position: "below-fixed"
        },
        sidepanel: {
            hidden: false,
            position: "right"
        }
    }
};
