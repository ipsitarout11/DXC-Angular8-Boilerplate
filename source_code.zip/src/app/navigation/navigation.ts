import { DXCNavigation } from '@DXC/types';

export const navigation: DXCNavigation[] = [
    {
        id       : 'applications',
        title    : 'Applications',
        
        type     : 'group',
        icon     : 'apps',
        children : [
            {
                id       : 'dashboards',
                title: 'Analytics Dashboard',
                        type : 'item',
                        url  : '/apps/dashboards/analytics',
                icon     : 'dashboard',


            },
            
          
            
          
            
           
        ]
    },
    {
        id      : 'pages',
        title   : 'Sample Pages',
        type    : 'group',
        icon    : 'pages',
        children: [
            {
                id       : 'Extras',
                title    : 'Elements',
                
                type     : 'item',
                icon     : 'account_box',
                url  : '/angular-material-elements/data-tables'
            },
          
            {
                id      : 'pricing',
                title   : 'Cards Variant',
                type    : 'collapsable',
                icon    : 'attach_money',
                children: [
                   
                    {
                        id   : 'style',
                        title: 'Pricing Details',
                        type : 'item',
                        url  : '/pages/pricing/style'
                    }
                    
                ]
            },
            {
                id   : 'cards',
                title: 'UI Cards',
                type : 'item',
                icon    : 'import_contacts',
                url  : '/ui/cards'
            } ,

            {
                id       : 'SearchMechanism',
                title    : 'Search Mechanism',
                type     : 'item',
                icon     : 'school',
                url      : '/apps/search-mechanism'
            },
          
        
        ]
    },
  
    {
        id      : 'angular-material-elements',
        title   : 'Angular Material Elements',
        type    : 'group',
        icon    : 'layers',
        children: [
          
            {
                id      : 'data-table',
                title   : 'Data table',
                type    : 'collapsable',
                icon    : 'layers',
                children: [
                   
                    {
                        id   : 'table',
                        title: 'Table',
                        type : 'item',
                        url  : '/angular-material-elements/table'
                    }
                ]
            }
        ]
    }
   
 
];
