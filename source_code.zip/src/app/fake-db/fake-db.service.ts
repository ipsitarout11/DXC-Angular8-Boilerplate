import { InMemoryDbService } from 'angular-in-memory-web-api';

import { AnalyticsDashboardDb } from 'app/fake-db/dashboard-analytics';

import { SearchMechanismFakeDb } from 'app/fake-db/search-mechanism';




export class FakeDbService implements InMemoryDbService
{
    createDb(): any
    {
        return {
            // Dashboards
          
            'analytics-dashboard-chartTypes': AnalyticsDashboardDb.chartTypes,
// SearchMechanism
'searchmechanism-categories': SearchMechanismFakeDb.categories,
'search-items'   : SearchMechanismFakeDb.items,

           
        };
    }
}
