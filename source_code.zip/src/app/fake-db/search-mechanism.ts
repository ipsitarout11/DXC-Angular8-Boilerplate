export class SearchMechanismFakeDb
{
    public static items = [
        {
            'id'      : '1',
            'title'   : 'HTML Basics',
            'category': 'HTML',
            
            
        },
        {
            'id'      : '2',
            'title'   : 'Use of HTML',
            'category': 'HTML',
            
            
        },
        {
            'id'      : '3',
            'title'   : 'Jquery Learn',
           
            'category': 'Jquery',
            
            
        },
        {
            'id'      : '4',
            'title'   : 'Data Security',
            
            'category': 'Jquery',
            
            
        },
        {
            'id'      : '5',
            'title'   : 'Service Based',
            
            'category': 'Javascript',
            
            
        },
        {
            'id'      : '6',
            'title'   : 'Easy Tips',
            
            'category': 'HTML',
            
            
        },
        {
            'id'      : '7',
            'title'   : 'Website with CSS',
            
            'category': 'CSS',
            
            
        },
        {
            'id'      : '8',
            'title'   : 'Javascript Functions',
            
            'category': 'CSS',
            
            
        },
        {
            'id'      : '9',
            'title'   : 'Javascript Open Source Framework',
            
            'category': 'Javascript',
            
            
        },
        {
            'id'      : '10',
            'title'   : 'Building Beautiful UIs with Flutter',
            
            'category': 'HTML',
            
            
        },
        {
            'id'      : '11',
            'title'   : 'Javascript Uses',
            
            'category': 'CSS',
            
            
        },
        {
            'id'      : '12',
            'title'   : 'Customize',
           
            'category': 'HTML',
           
            
        },
        {
            'id'      : '13',
            'title'   : 'Javascript array',
            
            'category': 'Javascript',
         
            
        },
        {
            'id'      : '14',
            'title'   : 'CSS Jquery',
           
            'category': 'Jquery',
          
            
        },
        {
            'id'      : '15',
            'title'   : 'HTML for frontend',
           
            'category': 'HTML',
         
        },
        {
            'id'      : '16',
            'title'   : 'Your First HTML Website',
           
            'category': 'HTML',
            
            
        },
        {
            'id'      : '17',
            'title'   : 'Launch Javascript',
            
            'category': 'Javascript',
          
            
        },
        {
            'id'      : '18',
            'title'   : 'Personalize Your App with CSS ',
            
            'category': 'CSS',
            
            
        }
    ];

    public static categories = [
        {
            'id'   : 0,
            'value': 'HTML',
            'label': 'HTML'
        },
        {
            'id'   : 1,
            'value': 'CSS',
            'label': 'CSS'
        },
        {
            'id'   : 2,
            'value': 'Javascript',
            'label': 'Javascript'
        },
        {
            'id'   : 3,
            'value': 'Jquery',
            'label': 'Jquery'
        }
    ];


  

}
