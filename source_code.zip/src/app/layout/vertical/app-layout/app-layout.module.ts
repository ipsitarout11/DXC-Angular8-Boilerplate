import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { DXCSidebarModule } from '@DXC/components';
import { DXCSharedModule } from '@DXC/shared.module';


import { ContentModule } from 'app/layout/components/content/content.module';
import { FooterModule } from 'app/layout/components/footer/footer.module';
import { NavbarModule } from 'app/layout/components/navbar/navbar.module';

import { ToolbarModule } from 'app/layout/components/toolbar/toolbar.module';

import { VerticalLayoutComponent } from 'app/layout/vertical/app-layout/app-layout.component';

@NgModule({
    declarations: [
        VerticalLayoutComponent
    ],
    imports     : [
        RouterModule,

        DXCSharedModule,
        DXCSidebarModule,

        ContentModule,
        FooterModule,
        NavbarModule,
        
        ToolbarModule
    ],
    exports     : [
        VerticalLayoutComponent
    ]
})
export class VerticalLayoutModule
{
}
