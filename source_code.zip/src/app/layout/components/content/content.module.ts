import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { DXCSharedModule } from '@DXC/shared.module';

import { ContentComponent } from 'app/layout/components/content/content.component';

@NgModule({
    declarations: [
        ContentComponent
    ],
    imports     : [
        RouterModule,
        DXCSharedModule
    ],
    exports     : [
        ContentComponent
    ]
})
export class ContentModule
{
}
