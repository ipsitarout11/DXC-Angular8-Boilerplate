import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgModule } from '@angular/core';

import { DXCSharedModule } from '@DXC/shared.module';
import {Router, RouterModule} from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';


import { NavbarStyleModule } from 'app/layout/components/navbar/vertical/style/navbar-style.module';
import { DXCPerfectScrollbarDirective } from '@DXC/directives/DXC-perfect-scrollbar/DXC-perfect-scrollbar.directive';

import { NavbarComponent } from './navbar.component';


describe('NavbarComponent', () => {
    let component: NavbarComponent;
    let fixture: ComponentFixture<NavbarComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                RouterTestingModule,
                RouterModule,
                NavbarStyleModule,
                DXCSharedModule,
                // BrowserAnimationsModule,
            ],
            declarations: [ NavbarComponent ] ,
            providers: [ Router , DXCPerfectScrollbarDirective]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NavbarComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
