import { NgModule } from '@angular/core';

import { DXCSharedModule } from '@DXC/shared.module';

import { NavbarComponent } from 'app/layout/components/navbar/navbar.component';

import { NavbarStyleModule } from 'app/layout/components/navbar/vertical/style/navbar-style.module';

@NgModule({
    declarations: [
        NavbarComponent
    ],
    imports     : [
        DXCSharedModule,

       
        NavbarStyleModule,
       
    ],
    exports     : [
        NavbarComponent
    ]
})
export class NavbarModule
{
}
