import { Component, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { delay, filter, take, takeUntil } from 'rxjs/operators';

import { DXCConfigService } from '@DXC/services/config.service';
import { DXCNavigationService } from '@DXC/components/navigation/navigation.service';
import { DXCPerfectScrollbarDirective } from '@DXC/directives/DXC-perfect-scrollbar/DXC-perfect-scrollbar.directive';
import { DXCSidebarService } from '@DXC/components/sidebar/sidebar.service';

@Component({
    selector     : 'navbar-style',
    templateUrl  : './navbar-style.component.html',
    styleUrls    : ['./navbar-style.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class NavbarStyleComponent implements OnInit, OnDestroy
{
    DXCConfig: any;
    navigation: any;

    // Private
    private _DXCPerfectScrollbar: DXCPerfectScrollbarDirective;
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {DXCConfigService} _DXCConfigService
     * @param {DXCNavigationService} _DXCNavigationService
     * @param {DXCSidebarService} _DXCSidebarService
     * @param {Router} _router
     */
    constructor(
        private _DXCConfigService: DXCConfigService,
        private _DXCNavigationService: DXCNavigationService,
        private _DXCSidebarService: DXCSidebarService,
        private _router: Router
    )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    // Directive
    @ViewChild(DXCPerfectScrollbarDirective, {static: true})
    set directive(theDirective: DXCPerfectScrollbarDirective)
    {
        if ( !theDirective )
        {
            return;
        }

        this._DXCPerfectScrollbar = theDirective;

        // Update the scrollbar on collapsable item toggle
        this._DXCNavigationService.onItemCollapseToggled
            .pipe(
                delay(500),
                takeUntil(this._unsubscribeAll)
            )
            .subscribe(() => {
                this._DXCPerfectScrollbar.update();
            });

        // Scroll to the active item position
        this._router.events
            .pipe(
                filter((event) => event instanceof NavigationEnd),
                take(1)
            )
            .subscribe(() => {
                    setTimeout(() => {
                        this._DXCPerfectScrollbar.scrollToElement('navbar .nav-link.active', -120);
                    });
                }
            );
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {
        this._router.events
            .pipe(
                filter((event) => event instanceof NavigationEnd),
                takeUntil(this._unsubscribeAll)
            )
            .subscribe(() => {
                    if ( this._DXCSidebarService.getSidebar('navbar') )
                    {
                        this._DXCSidebarService.getSidebar('navbar').close();
                    }
                }
            );

        // Subscribe to the config changes
        this._DXCConfigService.config
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((config) => {
                this.DXCConfig = config;
            });

        // Get current navigation
        this._DXCNavigationService.onNavigationChanged
            .pipe(
                filter(value => value !== null),
                takeUntil(this._unsubscribeAll)
            )
            .subscribe(() => {
                this.navigation = this._DXCNavigationService.getCurrentNavigation();
            });
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Toggle sidebar opened status
     */
    toggleSidebarOpened(): void
    {
        this._DXCSidebarService.getSidebar('navbar').toggleOpen();
    }

    /**
     * Toggle sidebar folded status
     */
    toggleSidebarFolded(): void
    {
        this._DXCSidebarService.getSidebar('navbar').toggleFold();
    }
}
