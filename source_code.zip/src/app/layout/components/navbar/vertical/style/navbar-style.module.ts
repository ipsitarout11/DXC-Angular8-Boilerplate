import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import { DXCNavigationModule } from '@DXC/components';
import { DXCSharedModule } from '@DXC/shared.module';

import { NavbarStyleComponent } from 'app/layout/components/navbar/vertical/style/navbar-style.component';

@NgModule({
    declarations: [
        NavbarStyleComponent
    ],
    imports     : [
        MatButtonModule,
        MatIconModule,

        DXCSharedModule,
        DXCNavigationModule
    ],
    exports     : [
        NavbarStyleComponent
    ]
})
export class NavbarStyleModule
{
}
