DXC has a faily simple directory structure. All source code that you will need stays inside the /src folder.

Source directory (/src)

The source folder has the general Angular CLI project structure along with an additional folder called /@DXC which contains the core elements of our app .

/app
-----



This folder contains the AppComponent along with the following directories. Everything that being contained inside these 

folders are belong to your app and you can edit them however you like while building your app:

•	/fake-db: The fake database data files for DXC apps.
•	/DXC-config: The main config file for configuring the angular app .
•	/layout: Contains the template layout components.
•	/main: Example DXC apps and ready to use pages and page layouts.
•	/navigation: The main navigation data.
•	



