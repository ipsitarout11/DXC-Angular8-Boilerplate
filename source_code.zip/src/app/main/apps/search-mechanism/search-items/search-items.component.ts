import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { DXCAnimations } from '@DXC/animations';

import { SearchItemsService } from 'app/main/apps/search-mechanism/search-mechanism.service';

@Component({
    selector   : 'search-items',
    templateUrl: './search-items.component.html',
    styleUrls  : ['./search-items.component.scss'],
    animations : DXCAnimations
})
export class SearchItemsComponent implements OnInit, OnDestroy
{
    categories: any[];
    items: any[];
    itemsFilteredByCategory: any[];
    filtereditems: any[];
    currentCategory: string;
    searchTerm: string;

    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {SearchItemsService} _searchItemsService
     */
    constructor(
        private _searchItemsService: SearchItemsService
    )
    {
        // Set the defaults
        this.currentCategory = 'all';
        this.searchTerm = '';

        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {
        // Subscribe to categories
        this._searchItemsService.onCategoriesChanged
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(categories => {
                this.categories = categories;
            });

        // Subscribe to items
        this._searchItemsService.onitemsChanged
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(items => {
                this.filtereditems = this.itemsFilteredByCategory = this.items = items;
            });
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Filter items by category
     */
    filteritemsByCategory(): void
    {
        // Filter
        if ( this.currentCategory === 'all' )
        {
            this.itemsFilteredByCategory = this.items;
            this.filtereditems = this.items;
        }
        else
        {
            this.itemsFilteredByCategory = this.items.filter((item) => {
                return item.category === this.currentCategory;
            });

            this.filtereditems = [...this.itemsFilteredByCategory];

        }

        // Re-filter by search term
        this.filteritemsByTerm();
    }

    /**
     * Filter items by term
     */
    filteritemsByTerm(): void
    {
        const searchTerm = this.searchTerm.toLowerCase();

        // Search
        if ( searchTerm === '' )
        {
            this.filtereditems = this.itemsFilteredByCategory;
        }
        else
        {
            this.filtereditems = this.itemsFilteredByCategory.filter((item) => {
                return item.title.toLowerCase().includes(searchTerm);
            });
        }
    }
}
