import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';

import { DXCSharedModule } from '@DXC/shared.module';

import { SearchItemsComponent } from 'app/main/apps/search-mechanism/search-items/search-items.component';
import { SearchItemsService } from 'app/main/apps/search-mechanism/search-mechanism.service';
import { DXCSidebarModule } from '@DXC/components';

const routes = [
    {
        path     : 'items',
        component: SearchItemsComponent,
        resolve  : {
            searchmechanism: SearchItemsService
        }
    },
   
    {
        path      : '**',
        redirectTo: 'items'
    }
];

@NgModule({
    declarations: [
        SearchItemsComponent,
      
    ],
    imports     : [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatSelectModule,

        DXCSharedModule,
        DXCSidebarModule
    ],
    providers   : [
        SearchItemsService,
       
    ]
})
export class SearchMechanismModule
{
}
