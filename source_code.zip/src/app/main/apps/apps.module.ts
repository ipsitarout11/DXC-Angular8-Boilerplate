import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { DXCSharedModule } from '@DXC/shared.module';

const routes = [
    {
        path        : 'dashboards/analytics',
        loadChildren: './dashboards/analytics/analytics.module#AnalyticsDashboardModule'
    }, 
    
   
    {
        path        : 'search-mechanism',
        loadChildren: './search-mechanism/search-mechanism.module#SearchMechanismModule'
    },
  
    
];

@NgModule({
    imports     : [
        RouterModule.forChild(routes),
        DXCSharedModule
    ]
})
export class AppsModule
{
}
