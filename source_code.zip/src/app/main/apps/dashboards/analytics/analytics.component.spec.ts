/*import { Injectable } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { Subject } from 'rxjs';
// import { takeUntil } from 'rxjs/operators';
import {RouterModule, Router, Routes} from '@angular/router';

import { DXCConfigService } from '@DXC/services/config.service';
// import { DXCNavigationService } from '@DXC/components/navigation/navigation.service';
import { AnalyticsDashboardService } from 'app/main/apps/dashboards/analytics/analytics.service';

import { MediaObserver } from '@angular/flex-layout';
// import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { FakeDbService } from 'app/fake-db/fake-db.service';


import { AnalyticsDashboardComponent } from './analytics.component';
import {InjectionToken} from '@angular/core';
import { DXCCustomizedChartComponent } from '@DXC/components/customizedchart/customizedchart.component';
import { AnalyticsDashboardDb } from 'app/fake-db/dashboard-analytics';
import { InMemoryDbService } from 'angular-in-memory-web-api';



import { DXCWidgetToggleDirective } from '@DXC/components/customizedchart/customizedchart-toggle.directive';
import { ChartsModule } from 'ng2-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { DXCSharedModule } from '@DXC/shared.module';
import { DXCWidgetModule } from '@DXC/components/customizedchart/customizedchart.module';



// Create the injection token for the custom settings
export const DXC_CONFIG = new InjectionToken('DXCCustomConfig');


describe('AnalyticsDashboardComponent', () => {
  let component: AnalyticsDashboardComponent;
  let fixture: ComponentFixture<AnalyticsDashboardComponent>;
  const routes: Routes = [];
  beforeEach(async(() => {
    TestBed.configureTestingModule({
        imports: [
            RouterModule.forChild(routes),

            HttpClientModule,
            ChartsModule,
            NgxChartsModule,
            DXCSharedModule,
            DXCWidgetModule

        ],

        providers: [ AnalyticsDashboardService , MediaObserver  , HttpClient , HttpClientModule , DXCWidgetToggleDirective , AnalyticsDashboardDb ,
            InMemoryDbService , FakeDbService , {provide: DXCConfigService , useValue : DXC_CONFIG } , DXCCustomizedChartComponent ,
               { provide: Router }
        ],
      declarations: [ AnalyticsDashboardComponent  ]
    })
    .compileComponents();

    
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalyticsDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', async () => {
      fixture.detectChanges();
      expect(component).toBeTruthy();
  });
});
*/