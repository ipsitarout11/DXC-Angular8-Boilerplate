import { Component } from '@angular/core';

@Component({
    selector   : 'carded-fullwidth',
    templateUrl: './full-width.component.html',
    styleUrls  : ['./full-width.component.scss']
})
export class CardedFullWidthComponent
{
    /**
     * Constructor
     */
    constructor()
    {
    }
}
