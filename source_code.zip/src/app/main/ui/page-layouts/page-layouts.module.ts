import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';

import { DXCSharedModule } from '@DXC/shared.module';

import { CardedFullWidthComponent } from 'app/main/ui/page-layouts/carded/full-width/full-width.component';
import { CardedLeftSidebarComponent } from 'app/main/ui/page-layouts/carded/left-sidebar/left-sidebar.component';

import { SimpleFullWidthComponent } from 'app/main/ui/page-layouts/simple/full-width/full-width.component';
import { SimpleLeftSidebarComponent } from 'app/main/ui/page-layouts/simple/left-sidebar/left-sidebar.component';
import { BlankComponent } from 'app/main/ui/page-layouts/blank/blank.component';

import { DXCSidebarModule } from '@DXC/components';

const routes: Routes = [
    // Carded
   {
        path     : 'page-layouts/carded/full-width',
        component: CardedFullWidthComponent
    },
   
    {
        path     : 'page-layouts/carded/left-sidebar',
        component: CardedLeftSidebarComponent
    },
   
    // Simple
    {
        path     : 'page-layouts/simple/full-width',
        component: SimpleFullWidthComponent
    },
   
    {
        path     : 'page-layouts/simple/left-sidebar',
        component: SimpleLeftSidebarComponent
    },
    
    // Blank
    {
        path     : 'page-layouts/blank',
        component: BlankComponent
    }
];

@NgModule({
    declarations: [
      
        CardedFullWidthComponent,
       
        CardedLeftSidebarComponent,
      
        SimpleFullWidthComponent,
      
        SimpleLeftSidebarComponent,
      
        BlankComponent
    ],
    imports     : [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatIconModule,
        MatTabsModule,

        DXCSidebarModule,
        DXCSharedModule,
      
    ]
})
export class UIPageLayoutsModule
{

}
