import { Component } from '@angular/core';

@Component({
    selector   : 'simple-fullwidth',
    templateUrl: './full-width.component.html',
    styleUrls  : ['./full-width.component.scss']
})
export class SimpleFullWidthComponent
{
    /**
     * Constructor
     */
    constructor()
    {
    }
}
