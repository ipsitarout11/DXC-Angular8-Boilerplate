import { Component } from '@angular/core';

import { DXCSidebarService } from '@DXC/components/sidebar/sidebar.service';

@Component({
    selector   : 'simple-left-sidebar',
    templateUrl: './left-sidebar.component.html',
    styleUrls  : ['./left-sidebar.component.scss']
})
export class SimpleLeftSidebarComponent
{
    /**
     * Constructor
     *
     * @param {DXCSidebarService} _DXCSidebarService
     */
    constructor(
        private _DXCSidebarService: DXCSidebarService
    )
    {
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Toggle sidebar
     *
     * @param name
     */
    toggleSidebar(name): void
    {
        this._DXCSidebarService.getSidebar(name).toggleOpen();
    }
}
