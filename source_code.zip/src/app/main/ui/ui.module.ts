import { NgModule } from '@angular/core';

import { UICardsModule } from 'app/main/ui/cards/cards.module';
import { UIPageLayoutsModule } from 'app/main/ui/page-layouts/page-layouts.module';


@NgModule({
    imports: [
        UICardsModule,
     
        UIPageLayoutsModule
    
    ]
})
export class UIModule
{
}
