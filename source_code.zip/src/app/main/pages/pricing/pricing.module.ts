import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';

import { DXCSharedModule } from '@DXC/shared.module';


import { PricingStyleComponent } from 'app/main/pages/pricing/style/style.component';


const routes = [
    
    {
        path     : 'pricing/style',
        component: PricingStyleComponent
    }
    
];

@NgModule({
    declarations: [
        
        PricingStyleComponent
        
    ],
    imports     : [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatDividerModule,

        DXCSharedModule
    ]
})
export class PricingModule
{
}
