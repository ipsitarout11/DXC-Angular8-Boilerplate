import { Component, ViewEncapsulation } from '@angular/core';

@Component({
    selector     : 'pricing-style',
    templateUrl  : './style.component.html',
    styleUrls    : ['./style.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class PricingStyleComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }

}
