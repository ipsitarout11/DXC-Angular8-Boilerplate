import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {AbstractControl, FormBuilder, FormGroup, Validators , ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';


import { MatCardModule } from '@angular/material/card';

import { DXCSharedModule } from '@DXC/shared.module';

import { LoginComponent } from 'app/main/pages/authentication/login/login.component';


const routes = [
    {
        path     : 'auth/login',
        component: LoginComponent
    }
];

@NgModule({
    declarations: [
        LoginComponent
    ],
    imports     : [
        RouterModule.forChild(routes),
       // LoginRoutingModule,
       ReactiveFormsModule,
        MatButtonModule,
        MatCheckboxModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatCardModule,
        DXCSharedModule
    ]
})
export class LoginModule
{
}
