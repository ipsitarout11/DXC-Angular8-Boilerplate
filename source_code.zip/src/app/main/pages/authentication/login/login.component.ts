import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {AbstractControl, FormBuilder, FormGroup, Validators , ReactiveFormsModule } from '@angular/forms';
import { Router} from '@angular/router';
import { DXCConfigService } from '@DXC/services/config.service';
import { DXCAnimations } from '@DXC/animations';

// import custom validator to validate that password and confirm password fields match


@Component({
    selector     : 'login',
    templateUrl  : './login.component.html',
    styleUrls    : ['./login.component.scss'],
    encapsulation: ViewEncapsulation.None,
    animations   : DXCAnimations
})
export class LoginComponent implements OnInit
{
    
    registerForm: FormGroup;
   // private router: Router;
    submitted = false;

    /**
     * Constructor
     *
     * @param {DXCConfigService} _DXCConfigService
     * @param {FormBuilder} _formBuilder
     */
   constructor(
        private _DXCConfigService: DXCConfigService,
        private _formBuilder: FormBuilder ,
        private router: Router
    )
    {
        // Configure the layout
        this._DXCConfigService.config = {
            layout: {
                navbar   : {
                    hidden: true
                },
                toolbar  : {
                    hidden: true
                },
                footer   : {
                    hidden: true
                },
                sidepanel: {
                    hidden: true
                }
            }
        };
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
  /*  ngOnInit(): void
    {
        this.logingForm = this._formBuilder.group({
            email   : ['', [Validators.required, Validators.email]],
            password: ['', Validators.required]
        });
    } */

    // tslint:disable-next-line:typedef
   ngOnInit() {
        this.registerForm = this._formBuilder.group({
            
            email: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required, Validators.minLength(8)]],
            
           // acceptTerms: [false, Validators.requiredTrue]
        }, );
    }

    // convenience getter for easy access to form fields
    // tslint:disable-next-line:typedef
   
     get f() { return this.registerForm.controls; }
    
    // tslint:disable-next-line:typedef
    onSubmit() {

    }


    onButtonClick() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }

        // this.router.navigate(['/apps/dashboards/project']);

        // display form values on success
        alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));
        this.router.navigate(['/apps/dashboards/analytics']);

    }
}

    


