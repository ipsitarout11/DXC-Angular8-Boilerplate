import { Inject, Injectable, InjectionToken } from '@angular/core';
import {async, ComponentFixture, fakeAsync, inject, TestBed} from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import {AbstractControl, FormBuilder, FormGroup, Validators , ReactiveFormsModule } from '@angular/forms';
import { Router} from '@angular/router';
import { LoginComponent } from './login.component';
import { LoginModule } from './login.module';
import {DXCConfigService} from '@DXC/services/config.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {By} from '@angular/platform-browser';

// Create the injection token for the custom settings
export const DXC_CONFIG = new InjectionToken('DXCCustomConfig');


describe('LoginComponent', () => {
    let component: LoginComponent;
    let fixture: ComponentFixture<LoginComponent>;


    beforeEach(async(() => {

        TestBed.configureTestingModule({
            imports: [
                LoginModule,
                RouterTestingModule,
                BrowserAnimationsModule

            ],
            providers: [ {provide: DXCConfigService , useValue : DXC_CONFIG } ,
              //   { provide: Router, useValue: router }
            ],
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(LoginComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        // component.ngOnInit();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('form invalid when empty', () => {
        expect(component.registerForm.valid).toBeFalsy();
    });

    it('email field validity', () => {
        let errors = {};
        const email = component.registerForm.controls['email'];
        expect(email.valid).toBeFalsy();

        // Email field is required
        errors = email.errors || {};
        expect(errors['required']).toBeTruthy();

        // Set email to something
        email.setValue("test");
        errors = email.errors || {};
        expect(errors['required']).toBeFalsy();
        // expect(errors['pattern']).toBeTruthy();

        // Set email to something correct
        email.setValue("test@example.com");
        errors = email.errors || {};
        expect(errors['required']).toBeFalsy();
        //  expect(errors['pattern']).toBeFalsy();
    });
    it('password field validity', () => {
        let errors = {};
        const password = component.registerForm.controls['password'];

        // Email field is required
        errors = password.errors || {};
        expect(errors['required']).toBeTruthy();

        // Set email to something
        password.setValue("123456");
        errors = password.errors || {};
        expect(errors['required']).toBeFalsy();
        expect(errors['minlength']).toBeTruthy();

        // Set email to something correct
        password.setValue("123456789");
        errors = password.errors || {};
        expect(errors['required']).toBeFalsy();
        expect(errors['minlength']).toBeFalsy();
    });

    /*it('On submitting navigate to inner page', () => {
       // expect(component.registerForm.valid).toBeFalsy();
      //  component.registerForm.controls['email'].setValue("test@test.com");
      //  component.registerForm.controls['password'].setValue("123456789");
      //  expect(component.registerForm.valid).toBeTruthy();

        // let user: User;
        // Subscribe to the Observable and store the user in a local variable.
        // component.loggedIn.subscribe((value) => user = value);

        // Trigger the login function
        component.onSubmit();

        // Now we can check to make sure the emitted value is correct
        // expect(user.email).toBe("test@test.com");
        // expect(user.password).toBe("123456789");


        expect(router.navigate).toHaveBeenCalledWith(['/apps/dashboards/analytics']);

    }); */

   /* it('should navigate', inject([Router] , (router: Router) => {

        spyOn(router, 'navigate').and.stub();

        expect(router.navigate).toHaveBeenCalled();
    }));*/
   /* it(`will notify on direct onSumbit Call`, () => {
       //  spyOn(console, 'log');
        spyOn(console, 'log').and.callThrough();
        component.onSubmit();
        fixture.detectChanges();

        expect(console.log).toHaveBeenCalled(); // SUCCESS
    }); */
    it('should call onButtonClick ', fakeAsync(() => {
        const onClickMock = spyOn(component, 'onButtonClick');

        fixture.debugElement.query(By.css('button')).triggerEventHandler('click', null);
        expect(onClickMock).toHaveBeenCalled();
     //   expect(router.navigate).toHaveBeenCalled();
    }));
    it('should navigate ', fakeAsync(() => {

        
    }));
});
