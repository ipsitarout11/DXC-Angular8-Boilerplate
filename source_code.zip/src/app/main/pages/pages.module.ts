import { NgModule } from '@angular/core';

import { LoginModule } from 'app/main/pages/authentication/login/login.module';

//import { RegisterModule } from 'app/main/pages/authentication/register/register.module';
//import { ForgotPasswordModule } from 'app/main/pages/authentication/forgot-password/forgot-password.module';

import { PricingModule } from 'app/main/pages/pricing/pricing.module';

@NgModule({
    imports: [
        // Authentication
        
        LoginModule,
        
      //  RegisterModule,
        
       // ForgotPasswordModule,
       

        // Pricing
        PricingModule,

       
        
    ]
})
export class PagesModule
{

}
