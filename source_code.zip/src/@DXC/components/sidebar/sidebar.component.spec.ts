import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { animate, AnimationBuilder, AnimationPlayer, style } from '@angular/animations';
import { MediaObserver } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';

import { DXCSidebarComponent } from './sidebar.component';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {DXCConfigService} from '@DXC/services/config.service';
import {InjectionToken} from '@angular/core';
import { takeUntil } from 'rxjs/operators';

import { DXCSidebarService } from './sidebar.service';

// Create the injection token for the custom settings
export const DXC_CONFIG = new InjectionToken('DXCCustomConfig');


describe('DXCSidebarComponent', () => {
    let component: DXCSidebarComponent;
    let fixture: ComponentFixture<DXCSidebarComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [

                BrowserAnimationsModule ,
                RouterTestingModule,


            ],
            declarations: [ DXCSidebarComponent ],
            providers: [ AnimationBuilder , DXCSidebarService  ,
                {provide: DXCConfigService , useValue : DXC_CONFIG } ,
                takeUntil
            ],

        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DXCSidebarComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
