import { NgModule } from '@angular/core';

import { DXCSidebarComponent } from './sidebar.component';

@NgModule({
    declarations: [
        DXCSidebarComponent
    ],
    exports     : [
        DXCSidebarComponent
    ]
})
export class DXCSidebarModule
{
}
