import { NgModule } from '@angular/core';

import { DXCCustomizedChartComponent } from './customizedchart.component';


@NgModule({
    declarations: [
        DXCCustomizedChartComponent,
        
    ],
    exports     : [
        DXCCustomizedChartComponent,
      
    ],
})
export class DXCCustomizedChartModule
{
}
