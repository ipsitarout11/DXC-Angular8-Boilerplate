import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatRippleModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';

import { TranslateModule } from '@ngx-translate/core';

import { DXCNavigationComponent } from './navigation.component';
import { DXCNavVerticalItemComponent } from './vertical/item/item.component';
import { DXCNavVerticalCollapsableComponent } from './vertical/collapsable/collapsable.component';
import { DXCNavVerticalGroupComponent } from './vertical/group/group.component';

@NgModule({
    imports     : [
        CommonModule,
        RouterModule,

        MatIconModule,
        MatRippleModule,

        TranslateModule.forChild()
    ],
    exports     : [
        DXCNavigationComponent
    ],
    declarations: [
        DXCNavigationComponent,
        DXCNavVerticalGroupComponent,
        DXCNavVerticalItemComponent,
        DXCNavVerticalCollapsableComponent,
      ]
})
export class DXCNavigationModule
{
}
