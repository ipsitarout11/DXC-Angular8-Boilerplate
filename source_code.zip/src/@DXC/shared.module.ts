import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { FlexLayoutModule } from '@angular/flex-layout';

import { DXCDirectivesModule } from '@DXC/directives/directives';
//import { DXCPipesModule } from '@DXC/pipes/pipes.module';

@NgModule({
    imports  : [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,

        FlexLayoutModule,

        DXCDirectivesModule,
        //DXCPipesModule
    ],
    exports  : [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,

        FlexLayoutModule,

        DXCDirectivesModule,
       // DXCPipesModule
    ]
})
export class DXCSharedModule
{
}
