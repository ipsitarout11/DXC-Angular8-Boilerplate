
Services :
-----------
-----------


DXC Config
-----------

Config is a custom built DXC service allows to have a granular control over the DXC. It can be used for changing theme options (layout, color etc.) by component basis.

Usage
-----------

export class SomeComponent
{
    config: any;

    constructor(
        private _DXCConfigService: DXCConfigService
    )
    {
        // Fully customizable surroundings for this particular component
this._DXCConfigService.config = {
            colorTheme      : 'theme-default-dark',
            layout          : {
                style    : 'vertical-layout-1',
                width    : 'fullwidth',
                navbar   : {
                    primaryBackground  : 'DXC-navy-700',
                    secondaryBackground: 'DXC-navy-900',
                    folded             : false,
                    hidden             : false,
                    position           : 'left',
                    variant            : 'vertical-style-1'
                },
                toolbar  : {
                    customBackgroundColor: false,
                    background           : 'DXC-white-500',
                    hidden               : false,
                    position             : 'below-static'
                },
                footer   : {
                    customBackgroundColor: true,
                    background           : 'DXC-navy-900',
                    hidden               : false,
                    position             : 'below-fixed'
                },
sidepanel: {
                    hidden  : false,
                    position: 'right'
                }
            },
            customScrollbars: true
        });
    }

    onInit()
    {
        // Subscribe to config change
        this._DXCConfigService.config
            .subscribe((config) => {
                this.config = config;
            });
    }
}

DXC Splash Screen
-----------------


Splash screen is a custom DXC service that allows to have a control on the splash screen.

Usage
-----------


export class SomeComponent implements OnInit
{
    constructor(
        private _DXCSplashScreenService: DXCSplashScreenService
    ) {}

    ngOnInit()
    {
        this._DXCSplashScreenService.show();
  setTimeout(() => {
            this._DXCSplashScreenService.hide();
        }, 3000);
    }
}


