import { ModuleWithProviders, NgModule, Optional, SkipSelf } from '@angular/core';

import { DXC_CONFIG } from '@DXC/services/config.service';

@NgModule()
export class DXCModule
{
    constructor(@Optional() @SkipSelf() parentModule: DXCModule)
    {
        if ( parentModule )
        {
            throw new Error('DXCModule is already loaded. Import it in the AppModule only!');
        }
    }

    static forRoot(config): ModuleWithProviders
    {
        return {
            ngModule : DXCModule,
            providers: [
                {
                    provide : DXC_CONFIG,
                    useValue: config
                }
            ]
        };
    }
}
