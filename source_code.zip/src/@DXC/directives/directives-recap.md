
Directives 
-----------
-----------

DXCIfOnDom
-----------

*DXCIfOnDom is a helper directive that detaches and re-attaches the given element if it's currently in the DOM. This will help in various cases such as an animations thing that don't wait to route to be loaded completely.

Usage
-----------

<div *DXCIfOnDom></div>

DXCInnerScroll
-----------

DXCInnerScroll is a class directive that can be used in page layouts. It will lock the container's scroll allowing for individual scroll such as sidebar and the content itself.
This directive will only work with DXC's pre-built page layouts and it's a class directive.

Usage
-----------

<div class="page-layout carded left-sidebar inner-scroll">


DXCMatSidenav
-----------


DXCMatSidenav is a helper directive that enhances the Angular Material's sidenav. It modifies the sidenav so it will function like the Angular Material 1.x sidenav. It also has a service which you can register a sidenav in order to access and control its status from anywhere.

Usage
-----------

<mat-sidenav position="start" opened="true" mode="side"
             DXCMatSidenavHelper="chat-left-sidenav" mat-is-locked-open="gt-md">

Inputs
-----------

DXCMatSidenavHelperA unique name for the sidenav.

mat-is-locked-openAdds a locked open functionality just like Angular Material 1.x sidenav. Works with the media step aliases of the FlexLayout library.

Accessing to the sidebav methods from anywhere

constructor(
    private _DXCMatSidenavHelperService: DXCMatSidenavHelperService,
) {}

toggleSidenav()
{
    this._DXCMatSidenavHelperService.getSidenav('left-sidenav').toggle();
}

DXCPerfectScrollbar
-------------------

DXCPerfectScrollbar is an Angular directive for the Perfect Scrollbar library.

Usage
-----------

<div DXCPerfectScrollbar>
<div [DXCPerfectScrollbar]="false" [DXCPerfectScrollbarOptions]="{'updateOnRouteChange': true}">

Inputs
-----------

DXCPerfectScrollbarAccepts an optional boolean which you can control the Perfect Scrollbar. If provided false, Perfect Scrollbar will be destroyed or won't be initialized.
DXCPerfectScrollbarOptionsAccepts the Perfect Scrollbar options. In addition to those options, there is also a custom updateOnRouteChange option which updates the scrollbar on route changes. That's useful if your scrollbar wraps a router-outlet.
