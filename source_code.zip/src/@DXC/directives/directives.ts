import { NgModule } from '@angular/core';

import { DXCIfOnDomDirective } from '@DXC/directives/DXC-if-on-dom/DXC-if-on-dom.directive';
import { DXCInnerScrollDirective } from '@DXC/directives/DXC-inner-scroll/DXC-inner-scroll.directive';
import { DXCPerfectScrollbarDirective } from '@DXC/directives/DXC-perfect-scrollbar/DXC-perfect-scrollbar.directive';
import { DXCMatSidenavHelperDirective, DXCMatSidenavTogglerDirective } from '@DXC/directives/DXC-mat-sidenav/DXC-mat-sidenav.directive';

@NgModule({
    declarations: [
        DXCIfOnDomDirective,
        DXCInnerScrollDirective,
        DXCMatSidenavHelperDirective,
        DXCMatSidenavTogglerDirective,
        DXCPerfectScrollbarDirective
    ],
    imports     : [],
    exports     : [
        DXCIfOnDomDirective,
        DXCInnerScrollDirective,
        DXCMatSidenavHelperDirective,
        DXCMatSidenavTogglerDirective,
        DXCPerfectScrollbarDirective
    ]
})
export class DXCDirectivesModule
{
}
